﻿using System.Reflection;

[assembly: AssemblyTitle("RimUniverse.BiomesModule")]
[assembly: AssemblyProduct("RimUniverse.BiomesModule")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyTrademark("Balthoraz")]
[assembly: AssemblyVersion("1.01.0057")]